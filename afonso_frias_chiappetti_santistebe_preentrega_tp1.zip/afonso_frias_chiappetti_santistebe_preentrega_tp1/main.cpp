// Chiappetti Pablo
// Afonso Gaston
// Frias Magali
// Santistebe Mateo


#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int opcion = 0;
    string pausa;
    bool jugando = true;

int main() {

    while (jugando) {
        system("clear");
       cout << R"(
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@%**#@@@@@@@@@@@@@@@@**#@@@@@@@@@@@@@@@@@#**@@@@@@@@@@@@@@*******%@@@@@@@@@@@@@**#@@@**#@@@@@
@@@@@@@@....*@@@@@@@@@@@@@@#. -@@@@@@@@@@@@@@@@@= .@@@@@@@@@@@@@%. .::::*@@@@@@@@@@@@@. .:@@. -@@@@@
@@@@@@@-.:+..%@@@@@@@@@@@@@#. -@@@@@@@@@@@@@@@@@= .@@@@@@@@@@@@@%. .::::%@@@@@@@@@@@@@.....%. -@@@@@
@@@@@@+..%%..:@@@@@@@@@@@@@#. -@@@@@@@@@@@@@@@@@= .@@@@@@@@@@@@@%. =@@@@@@@@@@@@@@@@@@. =*... -@@@@@
@@@@@#...:::..=@@@@@@@@@@@@#. .....@@@@@@@@@@@@@= .@@@@@@@@@@@@@%. .....+@@@@@@@@@@@@@. =@@.. -@@@@@
@@@@@#**@@@@#**@@@@@@@@@@@@@*******@@@@@@@@@@@@@#**@@@@@@@@@@@@@@*******%@@@@@@@@@@@@@#*#@@@**#@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
)" << endl;
        cout << "1. Jugar\n";
        cout << "2. Opciones\n";
        cout << "3. Créditos\n";
        cout << "4. Salir\n";
        cout << "============================================================\n";
        cout << "Seleccioná una opción: ";
        cin >> opcion;

        switch (opcion) {
            case 1: {
                int decision1, decision2, decision3, decisionFinal, finalOpc;
                bool continuar = true;

                system("clear");
                cout << "Formas parte de la tripulación del U.S.C.S.S. Nostromo, una nave espacial de transporte comercial que regresa a la Tierra desde Thedus con un remolque de veinte millones de toneladas de mena.\n";
                cout << "Presione 1 + ENTER para continuar: ";
                cin >> pausa;

                system("clear");
                cout << "El ordenador central de la nave, «Madre», despierta a la tripulación, que en un principio cree que están en las proximidades de la Tierra. Sin embargo, descubren que se hallan en una región fuera del sistema solar.\n";
                cout << "El capitán Dallas les comenta que la computadora ha cambiado el rumbo de la nave para acudir a una señal anormal.\n";
                cout << "1. Continuar el rumbo del ordenador central e investigar sobre la extraña señal\n";
                cout << "2. Ignorar el protocolo del ordenador central e retomar el regreso a la tierra\n";
                cin >> decision1;

                if (decision1 == 2) {
                    cout << "\nRetoman a la tierra ignorando el protocolo del ordenador central y reciben una multa.\nGAME OVER\n";
                    cout << "Presione 1 + ENTER para volver al menu: ";
                    cin >> pausa;
                    break;
                }

                system("clear");
                cout << "La Nostromo llega a la luna de un planeta gaseoso e inexplorado.\n";
                cout << "La tripulación desengancha la nave del remolque y descienden hacia el origen de la señal.\n";
                cout << "Presiona 1 + ENTER para continuar: ";
                cin >> pausa;

                system("clear");
                cout << "Dallas, Kane y Lambert salen a investigar el origen de la señal.\n";
                cout << "Presione 1 + ENTER para continuar: ";
                cin >> pausa;

                system("clear");
                cout << "Descubren una nave alienígena abandonada y restos fosilizados de un extraterrestre gigante.\n";
                cout << "Mientras tanto, Ripley descubre que el mensaje era una advertencia, no una solicitud de ayuda.\n";
                cout << "Kane encuentra huevos en la nave abandonada y uno de ellos libera una criatura que lo deja inconsciente.\n";
                cout << "1. Permitir el ingreso de Dallas, Kane y Ripley\n";
                cout << "2. Decidir no permitir el ingreso de los tripulantes\n";
                cin >> decision2;

                if (decision2 == 2) {
                    system("clear");
                    cout << "\nKane muere debido a la falta de ayuda. La tripulación se mata entre sí. GAME OVER\n";
                    cout << "\nPresione 1 + ENTER para volver al menu: ";
                    cin >> pausa;
                    break;
                }

                system("clear");
                cout << "Ash permite entrar a los tripulantes, a pesar del protocolo de cuarentena.\n";
                cout << "La criatura se desprende de Kane por sí sola. La nave se repara y retoman el viaje hacia la Tierra.\n";
                cout << "Presione 1 + ENTER para continuar: ";
                cin >> pausa;

                system("clear");
                cout << "Kane despierta, pero durante la comida, una larva emerge violentamente de su pecho.\n";
                cout << "La tripulación intenta localizar al Alien usando lanzallamas y sensores de movimiento.\n";
                cout << "Presione 1 + ENTER para continuar: ";
                cin >> pausa;

                system("clear");
                cout << "¿A qué miembro eliges?\n";
                cout << "1. Brett\n2. Dallas\n3. Ash\n4. Lambert\n5. Parker\n6. Ripley\n";
                cin >> decision3;

                switch(decision3) {
                    case 1:
                    system("clear");
                        cout << "\nMientras buscas a «Jones», el gato de la tripulación, encuentras al Alien ya desarrollado y te mata.\n";
                        cout << "GAME OVER.\nPresione 1 + ENTER para volver al menu: ";
                        cin.ignore();
                        cin.get();
                        break;
                    case 2:
                    system("clear");
                        cout << "\nSigues al Alien, pero te embosca y te mata.\n";
                        cout << "GAME OVER.\nPresione 1 + ENTER para volver al menu: ";
                        cin.ignore();
                        cin.get();
                        break;
                    case 3:
                    system("clear");
                        cout << "\nLa tripulación descubre que eres un robot programado para llevar la nave al dueño corporativo con el Alien a bordo.\n";
                        cout << "Morís decapitado e incinerado.\n";
                        cout << "GAME OVER.\nPresione 1 + ENTER para volver al menu: ";
                        cin.ignore();
                        cin.get();
                        break;
                    case 4:
                    system("clear");
                        cout << "\nJunto a Parker y Ripley, intentas llevar a cabo un plan de autodestrucción, pero el Alien te embosca y mueres.\n";
                        cout << "GAME OVER.\nPresione 1 + ENTER para volver al menu: ";
                        cin.ignore();
                        cin.get();
                        break;
                    case 5:
                    system("clear");
                        cout << "\nJunto a Lambert y Ripley, intentas llevar a cabo un plan de autodestrucción, pero el Alien te embosca y mueres.\n";
                        cout << "GAME OVER.\nPresione 1 + ENTER para volver al menu: ";
                        cin.ignore();
                        cin.get();
                        break;
                    case 6:
                    system("clear");
                    cout << R"(-::::::::::::::::::::::::#%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#*#=--::::::::::::....:::::::::::-
-:::::::::::::::::::-+===+@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#*=---:::::::::::::::::::::::::-
-:::::::::::::::::---###@@@@@@@@@@@@@@@@@@%#%%@@@@@@@@@@@@@@@@@@@@@@@@@@@%+-=--::::::::::::::::::::::::-
-::::::::::::::::::=-*#%@@@@@@@@@@@@@@@%*+--==+*%@@@@@@@@@@@@@@@@@@@@@@@@##----::::::::::::::::::::::::-
-::::::::::::::::::+*@@@@@@@@@@@@@@@#*=-::..::-=#*%@@@@@@@@@@@@@@@@@@@@@@@===-=::::::::::::::::::::::-
-:::::::::::::::::#%@@@@@@@@@@@@@@@+:......:::--==+#@@@@@@@@@@@@@@@@@@@@%--=-=::::::::::::::::::::::-
-:::::::::::::::::=@@@@@@@@@@@@@@@%%+-:.....:::::--=+#@@@@@@@@@@@@@@@@@@@+-==---:::::::::::::::::::::-
-:::::::::::::::::+%@@@@@@@@@@@@@#+=-::.....:::::--=++*#@@@@@@@@@@@@@@@@%%*+==:::::::::::::::::::::::-
-:::::::::::::::::+@@@@@@@@@@@@@%=-:::......:=++++=++++++*@@@@@@@@@@@@@@@@@+=-=:::::::::::::::::::::::-
=:::::::::::::::::::+%@@@@@@@@@@@%+-:::::::::-+**++++++++++++*@@@%**%@@@@@@@@@@@#+=::::::::::::::::::::::-
=:::::::::::::::::::=%%@@@@@@@@@%+++===-::-=+**+%@#**+=--=+*@@%#+=@@@@@@@@@@@%%#-::::::::::::::::::::::-
=:::::::::::::::::::+%@@@@@@@@@@==+####=::==-=:-==+-::--=+*%@#+==@@@@@@@@@%#*=*=::::::::::::::::::::-
=::::::::::::::::::::==+#@@@@@@@@%%+=%%--::-=--::::::::--=+*###++%@@@@@@@@@@%#%%%=::::::::::::::::::::-
=-::::::::::::::::::--=#%@@@@@@@@@=+++=---:-=--::::::---=+***#@@@@@@@@@@@@@@@@@@@%%+::::::::::::::::::-
=---::::::::::::::::::-##@%@@@@@@=----:--:--=-::::::---=+++*#@@@@@@@@@@@@@@@@@%%@+=:::::::::-::------
=----:::::::::::::::-%#%%@@@@@@@@+---::-:.-===+::::---=++++#@@@@@@@@@@@@@@@@@@@@%*=-:---------------=
=------::::::::::::::-++%@%@@@@@@@=-----+**#+=-:::---==++=++#@@@@@@@@@@@@@@@@@@@@@+-----------------=
=------:::::::::::::::-==%=#@%%@@@@==---::--:::::----=====+*%@@@@@@@@@@@@@@@@@@@%%#*-----------------=
=-------:::::::::::::::-:++*+%@@@@@@@+=----==++***+==-====+*%@@@@@@@@@@@@@@@@@@@@#***+=============---=
=---------::::::::::::::-=+=*+#@@@@@@@+==++=---=+========+*@@@@@@@@@@@@@@@@@@@@@@#**%+==================
=------------:::::::::::-+##%#*%@@@@@@*====+++++======+*%@@@@@@@@@@@@@@@@@@@@@@@@@@%@@%+=================+
=-------------:::::::::::::::=+*%@@@@@@@#+++=-------==+%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%+===============+
=------------------:::::::::::-+@@@@@@@@@#==----==+*%@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@%#*+================+
=-------------------:::::::::::::-+@%@%@@@@@%*+*#%%@@@%###@@@@@@@@@@@@@@@@@@@@@@@@%@%###+===========+=+++++
=----------------------::::::::::-**==#@@@@@@@@@%######%@%@@@@@@@@@@@@@@@@@@@@#%#*++++++=========++++++++
=--------------------------::::::--%@@@@@@@@@@@@@@%####@%%@@@@@@@@@@@@@@@@@@%#***++++*****+===++++++++++
==-----------------------------------+@@@@@@@@%@@*#%#%%@@@@@@%@@@@@@@@@@@#******++*******#**++++++++++*
===----------------------------------+@@@@@@@%@@%++****##%@@%%@@@@@%#@%***********#######%*++++++++*
=====-------------------------------=@@@%%@@@@@@#=-=*+#%%@@@@@@@@@%###@****#***#***#####%%%@#++++++++*
+====------------------------------=#%#%%%%@@@@#+=--====*%#%@@%%%###%%**##*****#**#####%%@@@*++++++*
)"<<endl;
                        cout << "\nJunto a Lambert y Parker, intentas llevar a cabo un plan de autodestrucción y eres la encargada de iniciar la secuencia.\n";
                        cout << "Presione 1 + ENTER para continuar: ";
                        cin.ignore();
                        cin.get();

                        system("clear");
                        cout << "Te encuentras con el Alien que acaba de asesinar a tus compañeros.\n";
                        cout << "1. Enfrentar al Alien para llegar a la cápsula\n";
                        cout << "2. Detener la secuencia de autodestrucción para pensar en otra estrategia\n";
                        cin >> decisionFinal;

                        if (decisionFinal == 1) {
                            system("clear");
                            cout << "\nMorís asesinada por el Alien.\nGAME OVER.\nPresione 1 + ENTER para volver al menu: ";
                            cin.ignore();
                            cin.get();
                        } else if (decisionFinal == 2) {
                            system("clear");
                            cout << "\nEs demasiado tarde para detener la autodestrucción. Debes actuar rápido.\n";
                            cout << "Presione 1 + ENTER para continuar: ";
                            cin.ignore();
                            cin.get();

                            system("clear");
                            cout << "Decides llegar a la cápsula sin cruzarte con el Alien.\n";
                            cout << "Logras escapar dentro de la cápsula.\n";
                            cout << "Presione 1 + ENTER para continuar: ";
                            cin.ignore();
                            cin.get();

                            system("clear");
                            cout << "Dentro de la cápsula, el Alien intenta ingresar, pero logras expulsarlo al espacio.\n";
                            cout << "\n¡GANASTE!.\nPresione 1 + ENTER para volver al menu: ";
                            cin.ignore();
                            cin.get();
                        } else {
                            cout << "\nOpción inválida.\nPresione 1 + ENTER para continuar: ";
                            cin.ignore();
                            cin.get();
                        }
                        break;
                }
                break;
            }

            case 2:
                cout << "Opción no disponible.\n";
                cin >> pausa;
                break;

            case 3:
                 cout << "\nTRABAJO PRÁCTICO 1 - INFORMATICA GENERAL\n";
    cout << "Grupo: Nostromo\n";
    cout << "Integrantes: \n";
    cout << "   Gaston Afonso\n";
    cout << "   Magali Frias\n";
    cout << "   Pablo Chiappetti\n";
    cout << "   Mateo Santistebe\n";
    cin >> pausa;
                break;

            case 4:
                cout << "Gracias por jugar!\n";
                jugando = false;
                break;

            default:
                cout << "Opción inválida.\n";
                cin >> pausa;
                break;
        }
    }

    return 0;
}
